package Character;

public class Professor extends Character{
	
	public void initProfessor() {
		setAvailable(true);
		setURL("src\\JPG\\professor.png");
	}
	public void UseProfessor() {
		setAvailable(false);
	}
}
