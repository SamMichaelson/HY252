package Character;

import java.util.ArrayList;

import Player.PlayersHand;

public abstract class Character {
	private String URL;
	private boolean available;
	
	ArrayList<PlayersHand> chPlayer=new ArrayList<PlayersHand>();
	public ArrayList<PlayersHand> getChPlayer() {
		return chPlayer;
	}
	public void setChPlayer(ArrayList<PlayersHand> chPlayer) {
		this.chPlayer = chPlayer;
	}
	
	public boolean isAvailable() {
		return available;
	}
	public void setAvailable(boolean available) {
		this.available = available;
	}
	
	public String getURL() {
		return URL;
	}
	public void setURL(String URL) {
		this.URL = URL;
	}
}
