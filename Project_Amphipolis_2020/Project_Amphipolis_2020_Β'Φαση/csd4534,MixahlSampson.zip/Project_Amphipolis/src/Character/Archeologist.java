package Character;

public class Archeologist extends Character {
	
	public void initArcheologist() {
		setAvailable(true);
		setURL("src\\JPG\\archaeologist.png");
		}
	public void UseArcheologist() {
		setAvailable(false);
	}
}