package Character;

public class Assistant extends Character{
	
	public void initAssistant() {
		setAvailable(true);
		setURL("src\\JPG\\assistant.png");
	}
	public void UseAssistant() {
		setAvailable(false);
	}
}
