package Character;

public class Digger extends Character{

	public void initDigger() {
		setAvailable(true);
		setURL("src\\JPG\\digger.png");
	}
	public void UseDigger() {
		setAvailable(false);
	}

}
