package Controller;
/**
 * @author Μιχαήλ Σαμψών 
 * @University ID CSD4534
 * @Version B' Project  
 * @ 12/1/2021
 */

import Character.Archeologist;
import Character.Assistant;
import Character.Digger;
import Character.Professor;
import Player.PlayersHand;
import Player.Points;
import View.Board;
import View.Refresh;
import View.View;

public class Controller {
	View view=new View();
	Board board=new Board();
	PlayersHand playersHand =new PlayersHand();
	BAG bag= new BAG();
	Assistant assistant=new Assistant();
	Archeologist archeologist=new Archeologist();
	Digger digger=new Digger();
	Professor professor=new Professor();
	Points points=new Points();
	Refresh refresh=new Refresh();
	/**
	 * Shuffles cards and places them inside bag so they can be pulled randomly
	 *	sets one of each type in each corner	
	 */
	private void initialize() {
		view.setBack(refresh.getButtonTile());//sets background
		board.initBoard(bag.initBag());
		assistant.initAssistant();
		archeologist.initArcheologist();
		digger.initDigger();
		professor.initProfessor();
		
		
	}
	
	public static void main(String[] args) {

	        Controller c = new Controller();
	        c.initialize();
	}

	
	
	
}
