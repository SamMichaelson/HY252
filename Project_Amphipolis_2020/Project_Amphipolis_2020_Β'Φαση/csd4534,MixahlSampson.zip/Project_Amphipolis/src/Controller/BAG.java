package Controller;

import java.util.ArrayList;
import java.util.Collections;
import Model.AmphoraTile;
import Model.CaryatidTile;
import Model.LandslideTile;
import Model.MosaicTile;
import Model.SkeletonTile;
import Model.SphinxTile;
import Model.Tile;

public class BAG {
	AmphoraTile AmphT;
	CaryatidTile CaryT;
	LandslideTile LT;
	MosaicTile MosT;
	SkeletonTile SkT;
	SphinxTile SphT;
    private ArrayList<Tile> bagger = new ArrayList<Tile>();
    /*
     * Initializes the bag creating an array list 
     *	Also returns it 
     */
	public void setBagger(ArrayList<Tile> bagger) {
		this.bagger = bagger;
	}
	public ArrayList<Tile> getBagger() {
		return bagger;
	}
	/* 
	 * land count is the amount of landslide tiles on board and 
	 * Subtracts them until there are none
	 */
	private int landCount=16;
	public void LandCount() {
		landCount--;
	}
	public ArrayList<Tile> initBag() {
		CaryT=new  CaryatidTile();
		LT =new LandslideTile();
		SphT=new SphinxTile();
		
		for(int j=0;j<6;j++) {
			AmphT=new AmphoraTile();
			AmphT.setColer(j);
			AmphT.AmphoraTilee();
			for(int i=0;i<AmphT.getCount();i++) {
				bagger.add(AmphT);
			}
		}
		for(int i=0;i<CaryT.getCount();i++) {
			bagger.add(CaryT);
		}
		for(int i=0;i<LT.getCount();i++) {
			bagger.add(LT);
		}
		for(int j=0;j<3;j++) {
			MosT=new MosaicTile();
			MosT.setColer(j);
			MosT.MosaicTilee();
			for(int i=0;i<MosT.getCount();i++) {
				bagger.add(MosT);
			}
		}
		SkT=new SkeletonTile();
		SkT.setPart("top");
		SkT.setSize("big");
		SkT.SkeletonTilee();
		for(int i=0;i<SkT.getCount();i++) {
			bagger.add(SkT);
		}
		SkT=new SkeletonTile();
		SkT.setPart("top");
		SkT.setSize("small");
		SkT.SkeletonTilee();
		for(int i=0;i<SkT.getCount();i++) {
			bagger.add(SkT);
		}
		SkT=new SkeletonTile();
		SkT.setPart("bottom");
		SkT.setSize("big");
		SkT.SkeletonTilee();
		for(int i=0;i<SkT.getCount();i++) {
			bagger.add(SkT);
		}
		SkT=new SkeletonTile();
		SkT.setPart("bottom");
		SkT.setSize("small");
		SkT.SkeletonTilee();
		for(int i=0;i<SkT.getCount();i++) {
			bagger.add(SkT);
		}
		for(int i=0;i<SphT.getCount();i++) {
			bagger.add(SphT);
		}
		System.out.println("BAG inits "+bagger.size()+" elements");
		Collections.shuffle(bagger);
		setBagger(bagger);
		return bagger;
	}
	
	public boolean EndLand() {
		if(landCount<=0)
			return true;
		else 
			return false;
	}
	
}
