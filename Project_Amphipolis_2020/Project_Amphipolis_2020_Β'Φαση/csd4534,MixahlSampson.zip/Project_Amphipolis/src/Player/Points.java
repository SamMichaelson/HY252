package Player;

public class Points {
	PlayersHand player=new PlayersHand();
	public Points() {
		
	}
}
