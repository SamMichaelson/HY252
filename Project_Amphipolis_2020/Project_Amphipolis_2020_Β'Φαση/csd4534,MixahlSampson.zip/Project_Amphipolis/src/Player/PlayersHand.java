package Player;

import java.util.ArrayList;
import Model.Tile;

public class PlayersHand extends Player{

    ArrayList<Tile> tile=new ArrayList<Tile>();
	
	public ArrayList<Tile> getTile() {
		return tile;
	}

	public void setTile(ArrayList<Tile> tile) {
		this.tile = tile;
	}
	//All available characters
	public void AvChar() {
		
	}
	
	
}
