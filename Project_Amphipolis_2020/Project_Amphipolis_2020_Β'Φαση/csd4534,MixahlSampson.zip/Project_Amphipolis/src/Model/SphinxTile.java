package Model;

public class SphinxTile extends StatueTile{
	/*
	 * Constructs and sets photo and count
	 */
	public SphinxTile() {
		setPhoto("src\\JPG\\sphinx.png");
		setCount(12);	
	}
}
