package Model;

/**
 * 
 *Basically the class of the general tile
 * so that every subclass can feed of these 
 * (id,photo,count)
 *
 * */
public class Tile {
	private String id;
	private String photo;
	private int count;
	
	public void setId(String id) {
		this.id = id;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getId() {
		return id;
	}
	public String getPhoto() {
		return photo;
	}
	public int getCount() {
		return count;
	}

}
