package Model;

/*
 * Just sets the id
 */
public class StatueTile extends FindingTile{
	public StatueTile() {
		setId("top_right");
	}
}
