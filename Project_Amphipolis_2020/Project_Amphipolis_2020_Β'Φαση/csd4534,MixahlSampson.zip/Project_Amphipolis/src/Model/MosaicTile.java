package Model;

public class MosaicTile extends FindingTile{
	/*
	 * Has an array string and an int that guides to the colors
	 * when constructed
	 */
	private int coler;
	private String[] color={"green","red","yellow"};
	public void MosaicTilee() {
		setId("top_left");
		setPhoto("src\\JPG\\mosaic_"+color[coler]+".png");
		setCount(9);
	}

	public void setColer(int coler) {
		this.coler=coler;
	}

}
