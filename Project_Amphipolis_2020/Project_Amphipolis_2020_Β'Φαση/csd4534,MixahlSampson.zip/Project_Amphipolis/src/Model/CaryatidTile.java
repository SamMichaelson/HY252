package Model;

public class CaryatidTile extends StatueTile{
	/*
	 * Constructs and sets photo and count
	 */
	public CaryatidTile() {
		setPhoto("src\\JPG\\caryatid.png");
		setCount(12);
	}
}
