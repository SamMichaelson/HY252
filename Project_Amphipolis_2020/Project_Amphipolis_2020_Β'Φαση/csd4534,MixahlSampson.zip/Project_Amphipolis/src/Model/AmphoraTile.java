package Model;

public class AmphoraTile extends FindingTile {
	/**
	 * Has an array string and an int that guides to the colors
	 * when constructed
	 */
	private int coler;
	private String[] color={"brown","blue","green","purple","red","yellow"};

	public void setColer(int coler) {
		this.coler = coler;
	}
	public void AmphoraTilee() {
		setId("bottom_left");
		setPhoto("src\\JPG\\amphora_"+color[coler]+".png");
		setCount(5);
	}

}

