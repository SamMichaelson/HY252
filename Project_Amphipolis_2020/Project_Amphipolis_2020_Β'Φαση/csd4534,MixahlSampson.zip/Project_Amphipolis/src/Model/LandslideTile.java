package Model;

public class LandslideTile extends Tile {

	public LandslideTile() {
		setId("middle");
		setPhoto("src\\JPG\\landslide.png");
		setCount(24);

	}
}
