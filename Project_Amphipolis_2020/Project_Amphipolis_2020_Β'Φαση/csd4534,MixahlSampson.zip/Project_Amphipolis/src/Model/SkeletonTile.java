package Model;

public class SkeletonTile extends FindingTile {
	/*
	 * This class has 2 kinds of parts and 2 different sizes that 
	 * change the amount (count) and differentiate the image
	 */
	private String part;
	private String size;
	
	public void SkeletonTilee() {
		setId("bottom_right");
		if(size=="big") {
			setCount(10);
		}else {
			setCount(5);
			System.out.println("yahahoho");
		}
		setPhoto("src\\JPG\\skeleton_"+size+"_"+part+".png");	
	}
	
	public void setPart(String part) {
		this.part = part;
	}
	public void setSize(String size) {
		this.size = size;
	}
}
