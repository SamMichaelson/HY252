package View;

import java.awt.Image;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.SwingConstants;
import Character.Archeologist;
import Character.Assistant;
import Character.Digger;
import Character.Professor;
import Controller.BAG;
import Model.Tile;
import Player.PlayersHand;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;


public class View extends JFrame implements ActionListener{
	public View() {
	}
	private static final long serialVersionUID = 1L;
	
	Archeologist CharArch=new Archeologist();
	Assistant CharAss=new Assistant();
	Digger CharDig=new Digger();
	Professor CharProf=new Professor();
	BAG bag=new BAG();
	PlayersHand playersHand=new PlayersHand();

	private String namer;
//	private boolean viewWindow;
	private boolean buttonPress;
	String pName;
	int ii=0;
	/*
	 * Asks each of 4 players to instert their name one by one
	 * **broken feature not yet added lol*
	 */
	public String PlayersNames(int i) {/*
		ii=i;
		setButtonPress(false);
		viewWindow=true;
		this.setResizable(false);
		this.setTitle("Naming Screen");
		this.setAlwaysOnTop(true);
		this.getContentPane().setLayout(null);
		JLabel playersName=new JLabel("Player "+ (i+1) +" set your name then click NEXT");
		JLabel errormsg=new JLabel("");
		JButton next=new JButton("NEXT"); 
		JTextField name=new JTextField();
		name.setText("");
		playersName.setBounds(11,5,270,25);
		name.setBounds(10,35,270,25);  
		next.setBounds(10,70,270,25);  
		errormsg.setBounds(10, 100, 270, 25);
		this.getContentPane().add(next);  
		System.out.println(i);
		next.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				namer=name.getText();
				
				if(!name.getText().trim().isEmpty()) {
					//if jtext is not empty close window and call again
					System.out.println("heh");
					viewWindow=false;
					errormsg.setText("Valid name!");
					errormsg.setForeground(Color.green);
					setButtonPress(true);
					dispose();
					if(i<3) {
						View view=new View();
						view.PlayersNames(++ii);
					}
				}else {
					errormsg.setText("Invalid name, please try again");
					errormsg.setForeground(Color.red);
				}
			}
			
		});
		this.getContentPane().add(name);  
		this.getContentPane().add(playersName);
		this.getContentPane().add(errormsg);  
		this.getContentPane().setLayout(null); 
		this.setVisible(viewWindow);
        this.setPreferredSize(new Dimension(300, 170));
        this.pack();
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        */
		namer="Player"+i;
		return namer;
	}
	
	
	JFrame bgFrame=new JFrame("GAME");
	
	JLabel bgLabel=new JLabel(resize("src\\JPG\\background.png",650,650,Image.SCALE_SMOOTH));

	public int playercount=0;
	ArrayList<PlayersHand> playername=new ArrayList<PlayersHand>();
	JLabel Player=new JLabel();
			//playername.get(playercount).getPlayerName(),SwingConstants.CENTER);
	JLabel Chars=new JLabel("Use Character",SwingConstants.CENTER);
	JButton DrawTiles=new JButton("Draw Tiles");
	JButton EndTurn=new JButton("End Turn");
	
/*
 * Use an override class to constantly re-call 
 * frames and labels
 */	
	JLayeredPane ground=getLayeredPane();
	public void setBack(ArrayList<Tile> button) {
	}
	
	public void characters_used() {
		//if char is used use gray image
	}
	
	public ImageIcon resize(String URL,int x,int y,int sharpness) {
		ImageIcon img=new ImageIcon(URL);
		Image bg=img.getImage().getScaledInstance(x, y,sharpness);
		ImageIcon bbg=new ImageIcon(bg);
		return bbg;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
	}
	public boolean getButtonPress() {
		return buttonPress;
	}
	public void setButtonPress(boolean buttonPress) {
		this.buttonPress = buttonPress;
	}

}
