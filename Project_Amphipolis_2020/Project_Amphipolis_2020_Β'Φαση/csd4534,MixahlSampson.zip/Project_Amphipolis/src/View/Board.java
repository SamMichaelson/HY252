package View;

import java.util.ArrayList;
import java.util.ListIterator;

import Controller.BAG;
import Model.Tile;

public class Board {
	BAG bag=new BAG();
	View view=new View();
	Refresh refresh=new Refresh();
	
	//places one of each type on each side of board
	public void initBoard(ArrayList<Tile> bagger) {
		int base=0;
		System.out.println("Board bagger has "+bagger.size()+" elements");
		
		ListIterator<Tile> bigbag=bagger.listIterator();
		boolean tl=false,tr=false,bl=false,br=false,md=false;
		
		while(bigbag.hasNext()) {
			//System.out.println("heh "+bigbag.next().getId());
			//bigbag.previous();
			if(bigbag.next().getId()=="top_left"&&tl==false) {
				bigbag.previous();
				refresh.setLocation("top_left");
				refresh.setURL(bigbag.next().getPhoto());
				refresh.setBack(refresh.getButtonTile());
				bigbag.previous();
				base++;
				tl=true;
				bigbag.remove();
			//	System.out.println("tl");
			}else if(bigbag.next().getId()=="top_right"&&tr==false) {
				bigbag.previous();
				refresh.setLocation("top_right");
				refresh.setURL(bigbag.next().getPhoto());
				refresh.setBack(refresh.getButtonTile());
				bigbag.previous();
				base++;
				tr=true;
				bigbag.remove();
				//System.out.println("tr");
			}else if(bigbag.next().getId()=="bottom_left"&&bl==false) {
				bigbag.previous();
				refresh.setLocation("bottom_left");
				refresh.setURL(bigbag.next().getPhoto());
				refresh.setBack(refresh.getButtonTile());
				bigbag.previous();
				base++;
				bl=true;
				bigbag.remove();
			//	System.out.println("bl");
			}else if(bigbag.next().getId()=="bottom_right"&&br==false) {
				bigbag.previous();
				refresh.setLocation("bottom_right");
				refresh.setURL(bigbag.next().getPhoto());
				refresh.setBack(refresh.getButtonTile());
				bigbag.previous();
				base++;
				br=true;
				bigbag.remove();
		//		System.out.println("br");
			}else if(bag.getBagger().toString()=="middle"&& md==false) {
				bigbag.previous();
				refresh.setLocation("middle");
				refresh.setURL(bigbag.next().getPhoto());
				refresh.setBack(refresh.getButtonTile());
				bigbag.previous();
				base++;
				md=true;
				bigbag.remove();
				//System.out.println("md");
			}
			System.out.println(bagger.size());
			if(base==4) {
				break;
			}
		}System.out.println("HEHEBOY"+bagger.size());
		refresh.setBagger(bagger);
	}

}
