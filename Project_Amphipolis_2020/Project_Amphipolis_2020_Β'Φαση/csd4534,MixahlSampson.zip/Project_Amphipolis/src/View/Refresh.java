package View;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ListIterator;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import Model.Tile;
import Player.PlayersHand;


public class Refresh extends View {
	/**
	 *	Location is tiles position 
	 *	URL is the url of the corresponding photo of tile 
	 */
	private static final long serialVersionUID = 1L;
	private String location;
	private String URL;
	
	public String getLocationn() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getURL() {
		return URL;
	}
	public void setURL(String uRL) {
		URL = uRL;
	}
	//ARRAY LIST OF THE BUTTONS ON BOARD
	private ArrayList<Tile> buttonTile=new ArrayList<Tile>();
	public ArrayList<Tile> getButtonTile() {
		return buttonTile;
	}
	public void setButtonTile(ArrayList<Tile> buttonTile) {
		this.buttonTile = buttonTile;
	}
	JLabel bgLabel=new JLabel(resize("src\\JPG\\background.png",650,650,Image.SCALE_SMOOTH));
	//BUTTON ARRAY LIST FOR EACH BOARD BUTTON
	private ArrayList<JButton> JbuttonTile=new ArrayList<JButton>();
	public ArrayList<JButton> getJbuttonTile() {
		return JbuttonTile;}
	public void setJbuttonTile(ArrayList<JButton> jbuttonTile) {
		JbuttonTile = jbuttonTile;}
	
	//LABEL ARRAY LIST FOR EACH PLAYER
	private ArrayList<JLabel> playerLabelTile=new ArrayList<JLabel>();
	public ArrayList<JLabel> getPlayerLabelTile() {
		return playerLabelTile;}
	public void setPlayerLabelTile(ArrayList<JLabel> playerLabelTile) {
		this.playerLabelTile=playerLabelTile;}
	
	//ARRAY LIST OF EACH PLAYERS HAND
	private ArrayList<PlayersHand> pHand=new ArrayList<PlayersHand>();
	public ArrayList<PlayersHand> getPHand() {
		return pHand;}
	public void setPHand(ArrayList<PlayersHand> pHand) {
		this.pHand=pHand;}
	int clickCount;
	
	public void p(int count) {
		if(count<4)
			pcount++;
		else
			pcount=0;
	}
	int pcount;
	String[] player={"Player 1","Player 2","Player 3","Player 4"};
	
	boolean hasDrawn;
	@Override
	public void setBack(ArrayList<Tile> buttonn) {
		//if landside tiles has 16 tiles ends game with screen
		if(bag.EndLand()) {
			JFrame END=new JFrame("END GAME");
			END.setAlwaysOnTop (true);			
			JLabel endLabel=new JLabel(new ImageIcon("src\\JPG\\go.gif"));
			END.getContentPane().add(endLabel);
			END.pack();
			END.setVisible(true);
		}
		//adds only 4 players.
		//Ο μονος τροπος που βρηκα να αρχικοποιησω τους παικτες
		if(pHand.size()<4) 
			pHand.add(playersHand);
		Player.setText(player[pcount]);
		Player.setHorizontalAlignment(SwingConstants.CENTER);
		Player.setVerticalAlignment(SwingConstants.CENTER);
		
		CharArch.initArcheologist();
		CharAss.initAssistant();
		CharDig.initDigger();
		CharProf.initProfessor();
		JButton buttonArch=new JButton(resize(CharArch.getURL(),100,150,Image.SCALE_SMOOTH));
		JButton buttonAss=new JButton(resize(CharAss.getURL(),100,150,Image.SCALE_SMOOTH));
		JButton buttonDig=new JButton(resize(CharDig.getURL(),100,150,Image.SCALE_SMOOTH));
		JButton buttonProf=new JButton(resize(CharProf.getURL(),100,150,Image.SCALE_SMOOTH));
		//Προβληματικη περιοχη καθως δεν περναει σε καθε παικτη σωστα
		//τα Tiles που επιλεξαν 
		int h=0,v=0,add=0;////////////////////////////////////////////////////////////
		if(playerLabelTile.size()>0) {	
			for(Tile handTiles:getPHand().get(pcount).getTile()) {
				//JLabel plTile:getPlayerLabelTile()) {
				playerLabelTile.remove(add);
				playerLabelTile.add(new JLabel(resize(handTiles.getPhoto(),45,45,Image.SCALE_SMOOTH)));
				if(h==8) {h=0; v++;}
					getPlayerLabelTile().get(add).setBounds(0+45*h++,655+45*v, 45, 45);
					ground.add(getPlayerLabelTile().get(add),Integer.valueOf(3));}
				add++;
		}////////////////////////////////////////////////////////////////////
		bgFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
//		System.out.println(location);
//		System.out.println(URL);
		ground.setBounds(0,0,650,850);
		//ground.setBounds(0,650, 650, 200);
		
		bgFrame.getContentPane().setLayout(null);
		bgFrame.getContentPane().setLayout(null);
		bgLabel.setBounds(0,0,650,650);
		Player.setBounds(650,0,214,100);
		Chars.setBounds(650,50,214,100);
				
		ground.add(bgLabel,Integer.valueOf(1));
		buttonArch.setBounds(650,150,100,150);
		buttonAss.setBounds(750,150,100,150);
		buttonDig.setBounds(650,300,100,150);
		buttonProf.setBounds(750,300,100,150);
		//Draw tiles button and listener
		DrawTiles.setBounds(650,450,200,100);
		DrawTiles.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!hasDrawn) {
					for(int dr=0;dr<4;dr++) 
						draw();
					e.setSource(null);
					hasDrawn=true;}
			}
		});
		//end turn button and listener
		EndTurn.setBounds(650,550,200,100);
		EndTurn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ee) {
				if(ee.getSource()==EndTurn) {
					p(pcount);
					System.out.println("ENDSTurn "+pcount);
					ee.setSource(null);
					clickCount=0;
					hasDrawn=false;
				}
			}
		});
		bgFrame.getContentPane().add(Player);
		bgFrame.getContentPane().add(Chars);
		bgFrame.getContentPane().add(buttonArch);
		bgFrame.getContentPane().add(buttonAss);
		bgFrame.getContentPane().add(buttonDig);
		bgFrame.getContentPane().add(buttonProf);
		bgFrame.getContentPane().add(DrawTiles);
		bgFrame.getContentPane().add(EndTurn);
		bgFrame.getContentPane().add(ground);

		bgFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		bgFrame.setSize(864,850);
		bgFrame.setVisible(true);
		

		Tile button=new Tile();
		button.setId(location);
		button.setPhoto(URL);
		getButtonTile().add(button);
		
		JbuttonTile.add(new JButton(resize(button.getPhoto(),45,45,Image.SCALE_SMOOTH)));
		setJbuttonTile(JbuttonTile);
		JButton[] tile=new JButton[JbuttonTile.size()];
		int i=0;
		Tile buttonbag=new Tile();
		int tr=0,tl=0,br=0,bl=0,md=0;//Horizontal counter for tiles
		int trv=0,tlv=0,brv=0,blv=0,mdv=0;//Vertical counter for tiles
		//places tiles on board
		while(i<buttonn.size()) {
			if(tr==4) {tr=0; trv++;}
			if(tl==4) {tl=0; tlv++;}
			if(br==4) {br=0; brv++;}
			if(bl==4) {bl=0; blv++;}
			if(md==4) {md=0; mdv++;}
			buttonbag=buttonn.get(i);
			tile[i]=new JButton();
			tile[i]=JbuttonTile.get(i);
			if(buttonbag.getId()=="top_left") {
				tile[i].setBounds(22+tl*45, 20+tlv*45, 45, 45);
				ground.add(tile[i], Integer.valueOf(2));
				tl++;
				tile[i].addActionListener(this);
			}else if(buttonbag.getId()=="top_right") {
				tile[i].setBounds(445+tr*45, 20+trv*45, 45, 45);
				ground.add(tile[i],Integer.valueOf(2));
				tr++;
				tile[i].addActionListener(this);
			}else if(buttonbag.getId()=="bottom_left") {
				tile[i].setBounds(25+bl*45, 445+blv*45, 45, 45);
				ground.add(tile[i],Integer.valueOf(2));
				bl++;
				tile[i].addActionListener(this);
			}else if(buttonbag.getId()=="bottom_right") {
				tile[i].setBounds(445+br*45, 445+brv*45, 45, 45);
				ground.add(tile[i],Integer.valueOf(2));
				br++;
				tile[i].addActionListener(this);
			}else if(buttonbag.getId()=="middle") {
				tile[i].setBounds(235+md*45, 285+mdv*45, 45, 45);
				ground.add(tile[i],Integer.valueOf(2));
				bag.LandCount();
				md++;
			}	
			i++;
			bgFrame.getContentPane().add(ground);
		}
		setButtonTile(buttonn);
		bgFrame.setVisible(true);
	}
	//Action listener of tiles
	@Override
	public void actionPerformed(ActionEvent ae) {
		int j=0;
		JButton[] tile=new JButton[getJbuttonTile().size()];
		while(j<getJbuttonTile().size()){
			if(clickCount<2){
				tile[j]=new JButton();
				tile[j]=JbuttonTile.get(j);
				if(ae.getSource()==tile[j]) {///IF TILE IS PRESSED
					
					playerLabelTile.add(new JLabel(resize(getButtonTile().get(j).getPhoto(),45,45,Image.SCALE_SMOOTH)));
					getPHand().get(pcount).getTile().add(getButtonTile().get(j));
					System.out.println("?????!?!?!?"+getButtonTile().get(j).getPhoto());
					JbuttonTile.remove(j);
					System.out.println("AFTR"+ JbuttonTile.size());
					getButtonTile().remove(j);
					System.out.println("AFTR"+ getButtonTile().size());	
					
					clickCount++;
				}
			}
			j++;
		}
	}

//draw 4 tiles
	public void draw() {
		Collections.shuffle(bagger);
		ListIterator<Tile> bigbag=bagger.listIterator();
		System.out.println(bagger.size());
		setLocation(bigbag.next().getId());
		bigbag.previous();
		setURL(bigbag.next().getPhoto());
		setBack(getButtonTile());
	}
	ArrayList<Tile> bagger;
	public void setBagger(ArrayList<Tile> bagger) {
		this.bagger=bagger;
	}
	
	
}


