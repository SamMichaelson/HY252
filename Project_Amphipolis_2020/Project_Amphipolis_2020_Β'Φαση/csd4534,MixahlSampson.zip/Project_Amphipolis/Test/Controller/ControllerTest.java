package Controller;

import org.junit.jupiter.api.Test;

class ControllerTest {

	@Test
	void testMain() {
		System.out.println("This Test Run!");
	}

}
