package Player;

import java.util.ArrayList;

import Controller.BAG;
import Model.Tile;

public class Player {
	Character character;
	String playerName;
    ArrayList<BAG> bag=new ArrayList<BAG>();		
	
	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public ArrayList<BAG> getTiles() {
	        return bag;
	}
}
