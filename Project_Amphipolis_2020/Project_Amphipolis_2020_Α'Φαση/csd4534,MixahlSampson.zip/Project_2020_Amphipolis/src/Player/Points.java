package Player;

import java.util.ArrayList;
public class Points {
	Player player=new Player();
	public void ArrayList<Player> getPlayerHand(){
		
	}
}
