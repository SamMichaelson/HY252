package Player;

public class PlayersHand extends Player{
	
	public void initHand(){
		character =new Character();
		character.setCharacters(true,true,true,true);//bool sets true all character cards
	}
	
	public void AvChar() {
		
	}
	
	public void playerDeck() {
		
	}
}
