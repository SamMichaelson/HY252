package Player;

import java.util.ArrayList;

public class Character {
	private boolean Assistant;
	private boolean Archeologist; 
	private boolean Digger;
	private boolean Professor;
	public void setCharacters(boolean assistant, boolean archeologist, boolean digger, boolean professor) {
		this.Assistant=assistant;
		this.Archeologist=archeologist;
		this.Digger=digger;
		this.Professor=professor;
	}
	ArrayList<PlayersHand> chPlayer=new ArrayList<PlayersHand>();
	public ArrayList<PlayersHand> getChPlayer() {
		return chPlayer;
	}
	public void setChPlayer(ArrayList<PlayersHand> chPlayer) {
		this.chPlayer = chPlayer;
	}
	

}
