package View;

import java.util.ArrayList;

import Controller.BAG;

public class Board {
	BAG bag=new BAG();
	View view=new View();
	public void initBoard() {
		int base=0;
		do {
			if(bag.getBagger().getId()=="top_left") {
				view.setLocation("top_left");
				base++;
				bag.getBagger().remove(0);
			}else if(bag.getBagger().getId()=="top_right") {
				view.setLocation("top_right");
				base++;
				bag.getBagger().remove(0);
			}else if(bag.getBagger().getId()=="bottom_left") {
				view.setLocation("bottom_right");
				base++;
				bag.getBagger().remove(0);
			}else if(bag.getBagger().getId()=="bottom_right") {
				view.setLocation("bottom_right");
				base++;
				bag.getBagger().remove(0);
			}else if(bag.getBagger().toString()=="middle") {
				view.setLocation("middle");
				base++;
				bag.getBagger().remove(0);
			}
		}while(base<5);
			
		
		
	}

}
