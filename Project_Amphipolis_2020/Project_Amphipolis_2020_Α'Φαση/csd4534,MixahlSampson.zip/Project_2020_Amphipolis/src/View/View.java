package View;

import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Controller.BAG;
import Player.Player;

import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
public class View extends JFrame {
	BAG bag=new BAG();
	private String location;
	private String playerName;
	boolean MultiPlayerButtonPressed;
	
	ImageIcon ic1=new ImageIcon("C:\\Users\\DellUser\\Downloads\\Four_Players.gif");  
	ImageIcon ic2=new ImageIcon("C:\\Users\\DellUser\\Downloads\\Player_vs_AI.gif");
	JFrame PlayerFrame=new JFrame("Choose Players");  
	boolean PlayersDefine;

	
	public boolean fourPlayers() { 
		JButton MultiPlayerButton=new JButton("Four Players",ic1);
		JButton SinglePlayerButton=new JButton("Player vs AI",ic2);  
		MultiPlayerButton.setBounds(10,10,500,300);  
		SinglePlayerButton.setBounds(10,310,500,300);  
		PlayerFrame.add(MultiPlayerButton);  
		PlayerFrame.add(SinglePlayerButton);  
		PlayerFrame.setLayout(null); 
		PlayerFrame.setVisible(true);
		PlayerFrame.setSize(530,650);
		PlayerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MultiPlayerButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("4 PLAYER MODE");
				PlayersDefine=true;
				PlayerFrame.dispose();
			}
		});
		SinglePlayerButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("SINGLE PLAYER MODE");
				PlayersDefine=false;
				PlayerFrame.dispose();
			}
		});
		return PlayersDefine;
		//via botton if players are four return true
	}


	public void setBack() {
		ImageIcon bg=new ImageIcon("src\\\\JPG\\\\background.png");
		JLabel bgLabel=new JLabel(bg);
		add(bgLabel);
		setVisible(true);
		bgLabel.setSize(1430,1430);
	}

	public void setLocation(String location) {
		this.location=location;
		
	}


	public void setPlayerName() {
		//opens window to ask for p1 p2 p3 and p4 name
		
		Player player=new Player();
		player.setPlayerName(playerName);
	}


	public void draw4() {
		bag.LandCount();
		
	}


	public void choose2() {
		// TODO Auto-generated method stub
		
	}
	
	
}
