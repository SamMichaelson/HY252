package Controller;

import java.util.ArrayList;
import java.util.Iterator;
/*
 * @author Μιχαήλ Σαμψών 
 * @University ID CSD4534
 * @Version A' Project
 * @7/12/2020
 */

import Player.Player;
import Player.PlayersHand;
import Player.Points;
import View.Board;
import View.View;

public class Controller {
	View view=new View();
	Board board=new Board();
	Player player=new Player();
	PlayersHand playersHand =new PlayersHand();
	BAG bag= new BAG();
	Points points=new Points();
	ArrayList<Player> p=new ArrayList<Player>();
	private void initialize() {
		//view.fourPlayers();//if players are four or one returns bool
		view.setVisible(true);
		view.setBack();//sets background image
		
		board.initBoard();//sets one of each type in each corner
		
		bag.shuffleBag();//Shuffles cards and places them inside bag so they can be pulled randomly
		
		
		for(int i=0;i<4;i++) {
			playersHand.initHand();//Adds and sets names our 4 players
			view.setPlayerName();
			p.add(playersHand);
		}
		
	}
	private void letsPlay() {
		do{
			Iterator<Player> play=p.iterator();
			view.draw4();
			view.choose2();
			
			play.next();
		}while(bag.bagger.isEmpty()||bag.EndLand()==true);
		
		
	}
	
	public static void main(String[] args) {

	        Controller c = new Controller();
	        c.initialize();
	        c.letsPlay();
	}

	
	
	
}
