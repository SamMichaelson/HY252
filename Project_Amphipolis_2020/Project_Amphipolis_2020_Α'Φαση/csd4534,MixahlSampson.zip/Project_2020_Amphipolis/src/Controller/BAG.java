package Controller;

import java.util.ArrayList;
import java.util.Collections;

import Model.AmphoraTile;
import Model.CaryatidTile;
import Model.LandslideTile;
import Model.MosaicTile;
import Model.SkeletonTile;
import Model.SphinxTile;
import Model.StatueTile;
import Model.Tile;
import TILES.MosaicTiles;

public class BAG {
	AmphoraTile AmphT;
	CaryatidTile CaryT;
	LandslideTile LT;
	MosaicTile MosT;
	SkeletonTile SkT;
	SphinxTile SphT;
    ArrayList<Tile> bagger = new ArrayList<Tile>();
	private int landCount=16;
	
	public void LandCount() {
		landCount--;
	}
	public void initBag() {
	    
		AmphT=new AmphoraTile();
		CaryT=new  CaryatidTile();
		LT =new LandslideTile();
		MosT=new MosaicTile();
		SkT=new SkeletonTile();
		SphT=new SphinxTile();
		for(int i=0;i<AmphT.getCount();i++) {
			for(int j=0;j<6;j++) {
				AmphT.setColer(j);
				bagger.add(AmphT);
			}
		}
		for(int i=0;i<CaryT.getCount();i++) {
			bagger.add(CaryT);
		}
		for(int i=0;i<LT.getCount();i++) {
			bagger.add(LT);
		}
		for(int i=0;i<MosT.getCount();i++) {
			for(int j=0;j<3;j++) {
				MosT.setColer(j);
				bagger.add(MosT);
			}
		}
		SkT.setPart("top");
		SkT.setSize("big");
		for(int i=0;i<SkT.getCount();i++) {
			bagger.add(SkT);
		}
		SkT.setPart("top");
		SkT.setSize("small");
		for(int i=0;i<SkT.getCount();i++) {
			bagger.add(SkT);
		}
		SkT.setPart("bottom");
		SkT.setSize("big");
		for(int i=0;i<SkT.getCount();i++) {
			bagger.add(SkT);
		}
		SkT.setPart("bottom");
		SkT.setSize("small");
		for(int i=0;i<SkT.getCount();i++) {
			bagger.add(SkT);
		}
		for(int i=0;i<SphT.getCount();i++) {
			bagger.add(SphT);
		}
	}
	public ArrayList<Tile> getBagger() {
		return bagger;
	}
	public void shuffleBag() {
		Collections.shuffle(bagger);
	}
	
	public boolean EndLand() {
		if(landCount==0)
			return true;
		else 
			return false;
	}
	
}
