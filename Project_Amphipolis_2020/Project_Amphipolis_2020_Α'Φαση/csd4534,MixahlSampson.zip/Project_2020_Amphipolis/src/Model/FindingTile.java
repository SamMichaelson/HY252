package Model;

public class FindingTile extends Tile {}