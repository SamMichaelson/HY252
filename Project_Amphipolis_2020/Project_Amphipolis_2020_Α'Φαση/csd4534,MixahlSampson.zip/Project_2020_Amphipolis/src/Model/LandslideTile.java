package Model;

public class LandslideTile extends Tile {
	id="middle";
	photos="src\\JPG\\landslide.png";
	count=24;
}
