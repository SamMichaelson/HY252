package Model;

public class StatueTile extends FindingTile{
	id="top_right";
	public StatueTile() {
		
	}
}
