package Model;

import java.util.ArrayList;

public class AmphoraTile extends FindingTile {
	private int coler;
	private String[] color={"blue","brown","green","purple","red","yellow"}
	id="bottom_left";
	photo="src\\JPG\\amphora_"+color[coler]+".png";
	count=5;
	
	public int getColer() {
		return coler;
	}
	public void setColer(int coler) {
		this.coler = coler;
	}

}
