package Model;

public class SphinxTile extends StatueTile{
	photo="src\\JPG\\sphinx.png";
	count=12;
	public SphinxTile() {
		
	}
}
