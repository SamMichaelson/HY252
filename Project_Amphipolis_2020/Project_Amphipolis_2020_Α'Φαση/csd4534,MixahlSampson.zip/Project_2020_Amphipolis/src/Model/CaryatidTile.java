package Model;

public class CaryatidTile extends StatueTile{
	photo="src\\JPG\\caryatid.png";
	count=12;
	public CaryatidTile() {
		
	}
}
