package Model;

public class MosaicTile extends FindingTile{
	private int coler;
	private String[] color={"green","red","yellow"};
	id="top_left";
	photo="src\\JPG\\mosaic_"+color[coler]+".png";
	count=9;

	public void setColer(int coler) {
		this.coler=coler;
	}

}
