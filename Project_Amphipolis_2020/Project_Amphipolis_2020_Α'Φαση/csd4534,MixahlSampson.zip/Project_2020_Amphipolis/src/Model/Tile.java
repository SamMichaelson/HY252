package Model;

import java.util.ArrayList;

public class Tile {
	private static String id="";
	private String photo="";
	private int count=0;


	public String getPhoto() {
		return photo;
	}
	public String getId() {
		return id;
	}
	public int getCount() {
		return count;
	}

}
