package Model;

public class SkeletonTile extends FindingTile {
	private String part;
	private String size;
	id="bottom_right";
	if(size="big")
		count=10;
	else
		count=5;
	
	photo="src\\skeleton_"+size+"_"+part+".png";
	public String getPart() {
		return part;
	}
	public void setPart(String part) {
		this.part = part;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public SkeletonTile() {
		
	}
}
